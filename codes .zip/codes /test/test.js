const readline = require('readline');
const { exec } = require('child_process');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Enter a number (1 or 2): ', (answer) => {
  if (answer === '1') {
  console.log("Its Press 1")
  } else if (answer === '2') {
   
      console.log('Output: Its 2');
    // });
  } else {
    console.log('Invalid input. Please enter either 1 or 2.');
    // rl.close();
  }
  
  rl.question('Enter another number (1 or 2): ', (answer) => {
    if (answer === '1') {
      // exec('node file3.js', (error, stdout, stderr) => {
      //   if (error) {
      //     console.error(`Error: ${error.message}`);
      //     return;
      //   }
        console.log("Output:Another 1");
      // });
    } else if (answer === '2') {
      // exec('node file4.js', (error, stdout, stderr) => {
      //   if (error) {
      //     console.error(`Error: ${error.message}`);
      //     return;
      //   }
        console.log(`Output: Second 2`);
      // });
    } else {
      console.log('Invalid input. Please enter either 1 or 2.');
    }
    
    rl.close();
  });
});
