const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("RegistrationContract", async function () {
    // Define your test cases here

    let registrationContract, accessRequest, revokeData;

    
beforeEach(async function () {
    [ownerAddress, user1, user2, user3] = await ethers.getSigners();
   /* This is deploying the contract. */
    const RegistrationContract = await ethers.getContractFactory("RegistrationContract");
    registrationContract = await RegistrationContract.deploy();
    await registrationContract.deployed();

    /* Deploying the AccessRequest contract and passing the address of the RegistrationContract to it. */
    const AccessRequest = await ethers.getContractFactory("AccessRequest");
    accessRequest = await AccessRequest.deploy(registrationContract.address);
    await accessRequest.deployed();

   /* Deploying the RevokeData contract and passing the address of the RegistrationContract and
   AccessRequest contract to it. */
    const RevokeData = await ethers.getContractFactory("RevokeData");
    revokeData = await RevokeData.deploy(registrationContract.address, accessRequest.address);
    await revokeData.deployed();

    
});
it("should add a new data owner", async function () {
    // Call the signUp function with a new data owner's details
  let registrationHash =  await registrationContract.signUp("Fahim", "1234", "555-5555", 0);
    console.log("Signup Data Registration Hash", registrationHash);
    const dataOwner = await registrationContract.dataOwners(ownerAddress.address);
    console.log("Registered Data owner Detail in Blockchain that done on registration hash above: ", dataOwner)
    expect(dataOwner.name).to.equal("Fahim");
    expect(dataOwner.uniqueID).to.equal("1234");
    expect(dataOwner.contactNumber).to.equal("555-5555");
    expect(dataOwner.blockchainAddress).to.equal(ownerAddress.address);
  });
  
  
  it("should add new medical data", async function () {
    await registrationContract.signUp("Fahim", "1234", "555-5555", 0);
    const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
    const payment = ethers.utils.parseEther("1.0");
    await registrationContract.addData(dataHash, payment);
    const dataOwner = await registrationContract.dataOwners(ownerAddress.address);
    console.log("Data Owner Hash:", dataOwner)
    expect(dataOwner.dataHash).to.equal(dataHash);
    expect(dataOwner.payment).to.equal(payment);
  });



  it("should throw an AccessDenied error for unregistered users", async () => {
    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
    //  let tryToAccess =  await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
    //  console.log("should throw an AccessDenied error for unregistered users:", tryToAccess)

      try {
      let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
console.log("Access Denied Try to Access not registered User:",restult)

      } catch (error) {
        if (error.reason === "Access Denied") {
          console.log("Access Denied event caught:", error);
        } else {
          console.log("Unknown error:", error);
        }
      }
  });

  it("should throw an AccessDenied due to Invalid purpose", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 1);

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  console.log("Data HAsh:", dataHash)
      let restult= await accessRequest.connect(ownerAddress).isRequestAccess(dataHash,3,"bio");
      console.log("Result:", restult)
  });
  it("should throw an AccessDenied due to requested medical data not available", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 1);

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
      let restult= await accessRequest.connect(ownerAddress).isRequestAccess(dataHash,1,"bio");
  });
  it("should throw an AccessDenied due to time period for access is valid", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);


    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
      let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
  });


  it("should throw anAccessDenied due to not enough balance", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);


    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
      let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
  });
  it("should throw anAccessDenied due time period for access is valid", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
     await accessRequest.payToContract({value:10000});

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
      let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
  });

  it("should throw anAccessDenied due to session time for access is valid & invalid", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
     await accessRequest.payToContract({value:10000});

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
  await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:1000});
      let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
  });
  it("Update the mappings with the new access information", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
     await accessRequest.payToContract({value:10000});

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  let updateData = await registrationContract.addData(dataHash, 1000); 
  console.log("Update Data  with Price of 1000 token:", updateData);
  await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:1000});
      // let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
  });

  it("successful (medical data) access request when all steps 1-10 are valid", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
     await accessRequest.payToContract({value:10000});

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
 let dataRequest = await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:1000});
  console.log("Request for Data with payment:". dataRequest)    
 let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
 console.log("Data Access Result:", restult)
});

  it("payments successful and Access Got", async () => {
    await registrationContract.signUp("Alice", "1234", "555-5555", 0);
    await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
     await accessRequest.payToContract({value:10000});

    // const instance = await Registration.deployed();
  const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
  const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";

  await registrationContract.addData(dataHash, 1000); 
  console.log("Balance Before Paying for data ",await user1.getBalance());
  let accessData =await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:1000000000000000});
  console.log("Access Data:", accessData)  
  let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
      console.log("Balance After Paid of Data ",await user1.getBalance());
  
  
    });

    it("medical data access granted", async () => {
      await registrationContract.signUp("Alice", "1234", "555-5555", 0);
      await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
       await accessRequest.payToContract({value:10000});
  
      // const instance = await Registration.deployed();
    const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
    const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";
  
    await registrationContract.addData(dataHash, 1000); 
    let results =await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:1000000000000000});
    let restult1= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
    console.log("Requested Data result:". results)
     let dataStatus =  await accessRequest.checkDataGranted(user1.address, dataHash);
     console.log("Data Status should be Granted: ", dataStatus);
     expect(dataStatus).equals("granted");
      });

    
      it("access denied due to unsuccessful payment", async () => {
        await registrationContract.signUp("Alice", "1234", "555-5555", 0);
        await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
         await accessRequest.payToContract({value:10000});
    
        // const instance = await Registration.deployed();
      const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
      const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";
    
      await registrationContract.addData(dataHash, 1000); 
      await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:100});
          let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
      
       let dataStatus =  await accessRequest.checkDataGranted(user1.address, dataHash);
       console.log("Data Status should be Granted: ", dataStatus);
       expect(dataStatus).equals("granted");
        });

        it.only("revoke contract payment due to illegitimate medical data", async () => {
          
          await registrationContract.signUp("Alice", "1234", "555-5555", 0);
          await registrationContract.connect(user1).signUp("Alice", "1234", "555-5555", 1);
          await accessRequest.payToContract({value:10000});
          // const instance = await Registration.deployed();
          const dataHash = await registrationContract.getBytesData("hello World") //"0x1234567890";
          const dataHash1 = await registrationContract.getBytesData("hello World By IUSer") //"0x1234567890";
        await registrationContract.addData(dataHash, 10000000000000); 
        await accessRequest.connect(user1).requestAccess(dataHash, "bio",1,1,{value:10000000000000});
        let restult= await accessRequest.connect(user1).isRequestAccess(dataHash,1,"bio");
         let dataStatus =  await accessRequest.checkDataGranted(user1.address, dataHash1);
         console.log("Data Status should be Granted: ", restult);
        //  expect(dataStatus).equals("granted");
        let revokeDataq = await  revokeData.payToContract({value:10000000000000});

         await accessRequest.setOwner(revokeData.address);

        await revokeData.connect(user1).reportData(dataHash);
        // console.log("Balance of Contract is :", )
        console.log("Before user1 Requester balance: ", await user1.getBalance());

        await revokeData.revokeData(user1.address,dataHash,10000000000000);
        console.log("After revokeData user1 Requester Balance: ", await user1.getBalance());



          });

          

  });