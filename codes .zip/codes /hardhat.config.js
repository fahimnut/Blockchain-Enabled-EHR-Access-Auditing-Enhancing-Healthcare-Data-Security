require("@nomiclabs/hardhat-waffle");
require("@nomiclabs/hardhat-etherscan");
// require("hardhat-contract-sizer");
require('dotenv').config();
// require("hardhat-erc1820");
// Using JavaScript
// require('@primitivefi/hardhat-dodoc');
// require('hardhat-storage-layout');
// require('hardhat-log-remover');
// require('hardhat-docgen');
// require('hardhat-output-validator');
// require('hardhat-cannon');


// require("@nomiclabs/hardhat-ethers");
// require("hardhat-deploy-ethers");
// require("hardhat-deploy");
// require("@symfoni/hardhat-react");
// require("hardhat-typechain");
// require("@typechain/ethers-v5");


// require('hardhat-gui');




// require("hardhat-gas-reporter");

const Private_Key = process.env.Private_Key;

module.exports = {
  defaultNetwork: "hardhat",
  networks: {
    localhost: {
      url: "http://127.0.0.1:7545"
    },
    hardhat: { 
    },
    
    bsc_test:{
      url:`https://data-seed-prebsc-2-s2.binance.org:8545/`,
      accounts: [`${Private_Key}`]

    },
    goerli: {
      url: `https://goerli.infura.io/v3/`,
      accounts: [`${Private_Key}`]
    },
    bsc_mainnet:{
      url:`https://bsc-dataseed.binance.org/`,
      accounts: [`${Private_Key}`]
    },
    poly_testnet:{
      url:`https://rpc-mumbai.maticvigil.com`,
      accounts: [`${Private_Key}`]
    },
    fauji:{
      url:`https://avalanche-fuji.infura.io/v3/dd5214a068f644fe84f38f6f29e64b0a`,
      accounts: [`${Private_Key}`]
    },
    avax:{
      url:`https://avalanche-mainnet.infura.io/v3/0bb65deaa1de4ae6b54726ab844467ac`,
      accounts: [`${Private_Key}`]
    }
  },
  solidity: {
    version: "0.8.18",
    settings: {
      optimizer: {
        enabled: true,
        runs: 100,
      },
      // viaIR: true

    }
  },


  docgen: {
    path: './docs',
    clear: true,
    runOnCompile: true,
  },


  outputValidator: {
    runOnCompile: true,
    errorMode: true,
    checks: {
        title: "error",
        details: "error",
        params: "error",
        returns: "error",
        compilationWarnings: "warning",
        variables: false,
        events: false
    },
    exclude: [],
},

  etherscan: { 
    apiKey: process.env.bscScanKey
    // {
    //   // avalancheFujiTestnet: 'T6F6UFB6SIY4CQWZX4A8H7Y16CE11892WB',
    //   // avalanche: 'T6F6UFB6SIY4CQWZX4A8H7Y16CE11892WB',
    // }
  },
  contractSizer: {
    alphaSort: true,
    disambiguatePaths: false,
    runOnCompile: true,
    strict: true,
  },

  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts"
  },
  mocha: {
    timeout: 200000
  }
}