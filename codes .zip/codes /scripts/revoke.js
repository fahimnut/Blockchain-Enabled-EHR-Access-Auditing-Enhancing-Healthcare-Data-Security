// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
const hre = require("hardhat");

async function main() {
        const regAddress= "0x03661bE03D2b4F03329fd57DDBF69Dc09c320B38";
        const acessReqAddress ="0xfD4E63814B9a74b3568C5680DF4723B0395cAF1A";

  const RevokeData = await hre.ethers.getContractFactory("RevokeData");
  const revokeData = await RevokeData.deploy(regAddress, acessReqAddress);

  await revokeData.deployed();
  console.log(
    `RevokeData Contract is deployed to ${revokeData.address}`
  );
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
